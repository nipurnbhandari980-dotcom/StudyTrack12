import React, { useEffect, useMemo, useState } from "react";
import { SafeAreaView, View, Text, ScrollView, Pressable, TextInput, StyleSheet, StatusBar } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const SUBJECTS = [
 {name:"Accountancy",code:"055",chapters:["Accounting for Partnership Firms","Admission of a Partner","Retirement and Death of a Partner","Dissolution of Partnership Firm","Accounting for Share Capital","Issue and Redemption of Debentures","Financial Statements of a Company","Analysis of Financial Statements","Accounting Ratios","Cash Flow Statement"]},
 {name:"Business Studies",code:"054",chapters:["Nature and Significance of Management","Principles of Management","Business Environment","Planning","Organising","Staffing","Directing","Controlling","Financial Management","Financial Markets","Marketing Management","Consumer Protection"]},
 {name:"Economics",code:"030",chapters:["National Income and Related Aggregates","Money and Banking","Determination of Income and Employment","Government Budget and the Economy","Balance of Payments","Indian Economy on the Eve of Independence","Indian Economy 1950–1990","Liberalisation, Privatisation and Globalisation","Human Capital Formation","Rural Development","Employment","Environment and Sustainable Development","Comparative Development Experiences"]},
 {name:"English Core",code:"301",chapters:["The Last Lesson","Lost Spring","Deep Water","The Rattrap","Indigo","Poets and Pancakes","The Interview","Going Places","My Mother at Sixty-Six","Keeping Quiet","A Thing of Beauty","A Roadside Stand","Aunt Jennifer’s Tigers","The Third Level","The Tiger King","Journey to the End of the Earth","The Enemy","On the Face of It","Memories of Childhood"]},
 {name:"Artificial Intelligence",code:"843",chapters:["Communication Skills","Self-Management Skills","ICT Skills","Entrepreneurial Skills","Green Skills","Python Programming","Data Science Methodology","Statistical Concepts","Machine Learning","AI Project Cycle"]},
 {name:"Entrepreneurship",code:"066",chapters:["Entrepreneurial Opportunity","Entrepreneurial Planning","Enterprise Marketing","Enterprise Growth Strategies","Business Arithmetic","Resource Mobilisation"]}
];

export default function App() {
 const [done,setDone] = useState({});
 const [tab,setTab] = useState("All");
 const [search,setSearch] = useState("");
 const [loaded,setLoaded] = useState(false);
 useEffect(()=>{ AsyncStorage.getItem("studytrack-progress").then(v=>{if(v)setDone(JSON.parse(v));}).catch(()=>{}).finally(()=>setLoaded(true)); },[]);
 useEffect(()=>{ if(loaded) AsyncStorage.setItem("studytrack-progress",JSON.stringify(done)).catch(()=>{}); },[done,loaded]);
 const total = SUBJECTS.reduce((n,s)=>n+s.chapters.length,0);
 const completed = Object.values(done).filter(Boolean).length;
 const percent = Math.round(completed/total*100);
 const visible = useMemo(()=>SUBJECTS.filter(s=>(tab==="All"||s.name===tab) && s.name.toLowerCase().includes(search.toLowerCase())),[tab,search]);
 const toggle = key => setDone(old=>({...old,[key]:!old[key]}));
 return <SafeAreaView style={styles.safe}>
  <StatusBar barStyle="light-content" backgroundColor="#111827"/>
  <View style={styles.header}><Text style={styles.brand}>STUDYTRACK 12</Text><Text style={styles.sub}>CBSE • CLASS XII • 2026–27</Text></View>
  <ScrollView contentContainerStyle={styles.body}>
   <View style={styles.hero}><Text style={styles.eyebrow}>YOUR BOARD EXAM PLANNER</Text><Text style={styles.percent}>{percent}%</Text><Text style={styles.heroText}>{completed} of {total} topics completed</Text><View style={styles.track}><View style={[styles.fill,{width:percent+"%"}]}/></View></View>
   <Text style={styles.section}>Subjects</Text>
   <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabs}>{["All",...SUBJECTS.map(s=>s.name)].map(t=><Pressable key={t} onPress={()=>setTab(t)} style={[styles.pill,tab===t&&styles.pillOn]}><Text style={[styles.pillText,tab===t&&styles.pillTextOn]}>{t}</Text></Pressable>)}</ScrollView>
   <TextInput value={search} onChangeText={setSearch} placeholder="Search subject..." placeholderTextColor="#98A2B3" style={styles.search}/>
   {visible.map(s=>{const count=s.chapters.filter(c=>done[s.code+c]).length;return <View key={s.code} style={styles.card}>
    <View style={styles.cardHead}><View><Text style={styles.cardTitle}>{s.name}</Text><Text style={styles.code}>CBSE code {s.code}</Text></View><Text style={styles.count}>{count}/{s.chapters.length}</Text></View>
    <View style={styles.miniTrack}><View style={[styles.miniFill,{width:(count/s.chapters.length*100)+"%"}]}/></View>
    {s.chapters.map((c,i)=>{const key=s.code+c;return <Pressable key={key} onPress={()=>toggle(key)} style={styles.topic}><View style={[styles.check,done[key]&&styles.checked]}>{done[key]?<Text style={styles.tick}>✓</Text>:null}</View><Text style={[styles.topicText,done[key]&&styles.strike]}>{i+1}. {c}</Text></Pressable>})}
   </View>})}
   <Text style={styles.note}>Progress saves automatically on this device. These are starter planning topics, not a verified final CBSE 2026–27 syllabus. Confirm chapter inclusion with your school and the official CBSE curriculum.</Text>
  </ScrollView>
 </SafeAreaView>;
}
const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:"#F3F5F9"},header:{backgroundColor:"#111827",padding:22,paddingTop:16},brand:{color:"#FFF",fontSize:21,fontWeight:"900",letterSpacing:1},sub:{color:"#AAB5C6",marginTop:4,fontSize:11,letterSpacing:1},
 body:{padding:16,paddingBottom:36},hero:{backgroundColor:"#18243A",borderRadius:18,padding:20,marginBottom:22},eyebrow:{color:"#DCE6F5",fontSize:11,letterSpacing:1},percent:{color:"#FFF",fontSize:42,fontWeight:"800",marginTop:8},heroText:{color:"#AAB5C6",fontSize:12},track:{height:8,backgroundColor:"#34435B",borderRadius:8,marginTop:15,overflow:"hidden"},fill:{height:8,backgroundColor:"#65C6A5",borderRadius:8},
 section:{fontSize:18,fontWeight:"800",color:"#172033",marginBottom:12},tabs:{marginBottom:12},pill:{paddingHorizontal:13,paddingVertical:9,backgroundColor:"#FFF",borderRadius:20,marginRight:8},pillOn:{backgroundColor:"#263B60"},pillText:{color:"#344054",fontSize:12},pillTextOn:{color:"#FFF"},search:{backgroundColor:"#FFF",borderRadius:12,padding:13,marginBottom:14,color:"#172033"},
 card:{backgroundColor:"#FFF",borderRadius:16,padding:15,marginBottom:14},cardHead:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},cardTitle:{fontSize:16,fontWeight:"800",color:"#172033"},code:{color:"#8A96A8",fontSize:11,marginTop:3},count:{fontSize:13,fontWeight:"700",color:"#316D61"},miniTrack:{height:5,backgroundColor:"#E8EDF2",borderRadius:5,marginTop:12,marginBottom:7,overflow:"hidden"},miniFill:{height:5,backgroundColor:"#65B99D"},
 topic:{flexDirection:"row",alignItems:"center",paddingVertical:9,borderBottomWidth:1,borderBottomColor:"#F0F2F5"},check:{width:20,height:20,borderWidth:1.5,borderColor:"#B7C0CC",borderRadius:6,marginRight:10,alignItems:"center",justifyContent:"center"},checked:{backgroundColor:"#2C8C72",borderColor:"#2C8C72"},tick:{color:"#FFF",fontWeight:"900",fontSize:13},topicText:{flex:1,color:"#344054",fontSize:13},strike:{textDecorationLine:"line-through",color:"#98A2B3"},note:{color:"#8A96A8",fontSize:11,lineHeight:17,marginTop:5}
});
