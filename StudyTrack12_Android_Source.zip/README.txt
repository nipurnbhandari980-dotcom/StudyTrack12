STUDYTRACK 12 - ANDROID APP SOURCE
This folder contains the Expo React Native app source.
It is not an APK yet.

The GitHub Actions workflow will create an installable DEBUG APK after these files
are placed in your GitHub repository and the workflow is run.
The chapter lists are starter planning topics; verify the final CBSE 2026-27
syllabus with your school and official CBSE curriculum.
